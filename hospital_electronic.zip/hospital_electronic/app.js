var firebaseConfig = {
    apiKey: "AIzaSyBKm3yqjeQ57EvnyLbrjvd4BPLWHOC_hQ0",
    authDomain: "e-hospital2021.firebaseapp.com",
    databaseURL: "https://e-hospital2021-default-rtdb.firebaseio.com",
    projectId: "e-hospital2021",
    storageBucket: "e-hospital2021.appspot.com",
    messagingSenderId: "1059168284976",
    appId: "1:1059168284976:web:ee4a6721bf6524852898f5"
};

firebase.initializeApp(firebaseConfig);
var firestore = firebase.firestore();

const db = firestore.collection("formData");

let  submitButton = document.getElementById('Sign me up');

submitButton.addEventListener("click", (e) => {
    e.preventDefault();

    let First_Name = document.getElementById('first_name').value;
    let Last_Name = document.getElementById('last_name').value;
    let Username = document.getElementById('username').value;
    let E_mail = document.getElementById('email').value;
    let Password = document.getElementById('password').value;
    let Retype_password = document.getElementById('password').value;

    db.doc().set({
        firstname: First_Name,
        last_name: Last_Name,
        username: Username,
        email: E_mail,
        password: Password,
        password: Retype_password
    }).then( () => {
        console.log("Data saved")
    }) .catch((error) => {
        console.log(error)
    })
    alert("your form has been submited successfully");
})